import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../auth/auth_cubit.dart';
import '../auth/auth_state.dart';
import '../features/catalog/catalog_list_screen.dart';
import '../features/clients/clients_list_screen.dart';
import '../features/dashboard/dashboard_cubit.dart';
import '../features/dashboard/dashboard_model.dart';
import '../features/inventory/inventory_list_screen.dart';
import '../features/proofs/proofs_list_screen.dart';
import '../features/sales/sales_list_screen.dart';
import '../theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, authState) {
        if (authState is! AuthAuthenticated) {
          return const Scaffold(
              body: Center(child: CircularProgressIndicator()));
        }

        return BlocProvider(
          create: (_) => DashboardCubit()..load(),
          child: Scaffold(
            backgroundColor: AppTheme.warmBackground,
            body: CustomScrollView(
              slivers: [
                // ─── Hero header ─────────────────────────────────────────
                SliverToBoxAdapter(
                  child: _HeroHeader(
                      user: authState.user,
                      onLogout: () => _confirmLogout(context)),
                ),

                // ─── Dashboard content ───────────────────────────────────
                SliverFillRemaining(
                  hasScrollBody: true,
                  child: BlocBuilder<DashboardCubit, DashboardState>(
                    builder: (context, dashState) {
                      if (dashState is DashboardLoading) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      if (dashState is DashboardError) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.error_outline,
                                    size: 56, color: AppTheme.textMuted),
                                const SizedBox(height: 16),
                                Text(dashState.message,
                                    textAlign: TextAlign.center),
                                const SizedBox(height: 16),
                                FilledButton(
                                  onPressed: () =>
                                      context.read<DashboardCubit>().load(),
                                  child: const Text('Réessayer'),
                                ),
                              ],
                            ),
                          ),
                        );
                      }

                      if (dashState is! DashboardLoaded) {
                        return const SizedBox.shrink();
                      }

                      return SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // ─── KPI Cards ──────────────────────────────
                            _KpiSection(metrics: dashState.metrics),

                            // ─── Recommendations ────────────────────────
                            if (dashState.recommendations.isNotEmpty)
                              _RecommendationsSection(
                                  recommendations: dashState.recommendations),

                            // ─── Module quick access ────────────────────
                            const _ModulesSection(),

                            const SizedBox(height: 32),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Se déconnecter ?'),
        content: const Text('Vous devrez ressaisir votre mot de passe.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              context.read<AuthCubit>().logout();
            },
            style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error),
            child: const Text('Déconnexion'),
          ),
        ],
      ),
    );
  }
}

// ─── Hero Header ───────────────────────────────────────────────────────────

class _HeroHeader extends StatelessWidget {
  final dynamic user;
  final VoidCallback onLogout;

  const _HeroHeader({required this.user, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.deepGreen, Color(0xFF0F7A56)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 12, 16, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Colors.white.withValues(alpha: 0.2)),
                    ),
                    child: const Icon(Icons.storefront_rounded,
                        color: Colors.white, size: 20),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: Icon(Icons.logout_rounded,
                        color: Colors.white.withValues(alpha: 0.8), size: 22),
                    onPressed: onLogout,
                    tooltip: 'Déconnexion',
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text('Bonjour,',
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.65),
                      fontSize: 14,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 2),
              Text(user.fullName,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5,
                      height: 1.15)),
              const SizedBox(height: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border:
                      Border.all(color: Colors.white.withValues(alpha: 0.2)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.alternate_email,
                        size: 13, color: Colors.white.withValues(alpha: 0.7)),
                    const SizedBox(width: 5),
                    Text(user.email,
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.85),
                            fontSize: 12,
                            fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── KPI Section ──────────────────────────────────────────────────────────

class _KpiSection extends StatelessWidget {
  final DashboardMetrics metrics;

  const _KpiSection({required this.metrics});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Aperçu',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppTheme.textMuted, letterSpacing: 1.5, fontSize: 11)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _KpiCard(
                icon: Icons.trending_up_rounded,
                value: metrics.revenueThisMonth.toString(),
                label: 'CA ce mois',
                unit: 'XAF',
                color: AppTheme.xafGold,
                trend: metrics.revenueTrend > 0
                    ? '+${metrics.revenueTrend.toStringAsFixed(0)}%'
                    : '${metrics.revenueTrend.toStringAsFixed(0)}%',
              ),
              _KpiCard(
                icon: Icons.receipt_long_rounded,
                value: metrics.ordersPaid.toString(),
                label: 'Commandes payées',
                unit: null,
                color: Color.lerp(AppTheme.forestGreen, Colors.green, 0.3)!,
              ),
              _KpiCard(
                icon: Icons.warning_amber_rounded,
                value: metrics.productsLowStock.toString(),
                label: 'Produits (stock bas)',
                unit: null,
                color: Colors.orange.shade700,
              ),
              _KpiCard(
                icon: Icons.lock_outline_rounded,
                value: metrics.proofsPending.toString(),
                label: 'Preuves en attente',
                unit: null,
                color: Colors.amber.shade700,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final String? unit;
  final Color color;
  final String? trend;

  const _KpiCard({
    required this.icon,
    required this.value,
    required this.label,
    this.unit,
    required this.color,
    this.trend,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.1), color.withValues(alpha: 0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: color, size: 18),
          ),
          const Spacer(),
          Row(
            textBaseline: TextBaseline.alphabetic,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            children: [
              Text(value,
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimary)),
              if (unit != null) ...[
                const SizedBox(width: 3),
                Text(unit!,
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textMuted)),
              ],
            ],
          ),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.textMuted,
                  height: 1.3)),
          if (trend != null) ...[
            const SizedBox(height: 4),
            Text(trend!,
                style: TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w600, color: color)),
          ],
        ],
      ),
    );
  }
}

// ─── Recommendations Section ───────────────────────────────────────────────

class _RecommendationsSection extends StatelessWidget {
  final List<Recommendation> recommendations;

  const _RecommendationsSection({required this.recommendations});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Recommandations',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppTheme.textMuted, letterSpacing: 1.5, fontSize: 11)),
          const SizedBox(height: 12),
          ...recommendations.map((rec) =>
              _RecommendationCard(recommendation: rec, key: ValueKey(rec.id))),
        ],
      ),
    );
  }
}

class _RecommendationCard extends StatelessWidget {
  final Recommendation recommendation;

  const _RecommendationCard({super.key, required this.recommendation});

  @override
  Widget build(BuildContext context) {
    final (borderColor, bgColor, icon) = switch (recommendation.severity) {
      RecommendationSeverity.urgent => (
          Colors.red.shade700,
          Colors.red.shade50,
          Icons.priority_high_rounded
        ),
      RecommendationSeverity.warning => (
          Colors.orange.shade700,
          Colors.orange.shade50,
          Icons.warning_rounded
        ),
      RecommendationSeverity.info => (
          AppTheme.forestGreen,
          Colors.green.shade50,
          Icons.info_rounded
        ),
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor.withValues(alpha: 0.3)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: borderColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(9)),
              child: Icon(icon, color: borderColor, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    recommendation.title,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    recommendation.description,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textMuted, height: 1.3),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: recommendation.action != null
                  ? () => recommendation.action!(context)
                  : null,
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                textStyle:
                    const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              ),
              child: Text(recommendation.actionLabel, maxLines: 1),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Modules Section ───────────────────────────────────────────────────────

class _ModulesSection extends StatelessWidget {
  const _ModulesSection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Accès rapide',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppTheme.textMuted, letterSpacing: 1.5, fontSize: 11)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _ModuleTile(
                icon: Icons.people_rounded,
                title: 'Clients',
                subtitle: 'Carnet',
                color: AppTheme.moduleClients,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ClientsListScreen())),
              ),
              _ModuleTile(
                icon: Icons.shopping_bag_rounded,
                title: 'Catalogue',
                subtitle: 'Produits',
                color: AppTheme.moduleCatalog,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CatalogListScreen())),
              ),
              _ModuleTile(
                icon: Icons.receipt_long_rounded,
                title: 'Devis',
                subtitle: 'Pipeline',
                color: AppTheme.moduleSales,
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SalesListScreen())),
              ),
              _ModuleTile(
                icon: Icons.inventory_2_rounded,
                title: 'Stock',
                subtitle: 'Inventory',
                color: AppTheme.moduleStock,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const InventoryListScreen())),
              ),
              _ModuleTile(
                icon: Icons.lock_rounded,
                title: 'Coffre-Fort',
                subtitle: 'Preuves',
                color: AppTheme.moduleProofs,
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const ProofsListScreen())),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ModuleTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _ModuleTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, Color.lerp(color, Colors.black, 0.22)!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                  color: color.withValues(alpha: 0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(14)),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const Spacer(),
                Text(title,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.2,
                        height: 1.2)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.65),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        height: 1.3)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
