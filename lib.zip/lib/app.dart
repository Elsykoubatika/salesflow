import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'auth/auth_cubit.dart';
import 'auth/auth_state.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/splash_screen.dart';
import 'theme.dart';

class SalesFlowApp extends StatelessWidget {
  const SalesFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AuthCubit(),
      child: MaterialApp(
        title: 'SalesFlow Pro Congo',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        home: BlocBuilder<AuthCubit, AuthState>(
          builder: (context, state) {
            // Aiguillage : un seul endroit, lisible.
            return switch (state) {
              AuthInitial() || AuthLoading() => const SplashScreen(),
              AuthAuthenticated() => const HomeScreen(),
              _ => const LoginScreen(),
            };
          },
        ),
      ),
    );
  }
}
